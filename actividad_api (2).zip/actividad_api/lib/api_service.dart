import 'package:http/http.dart' as http;
import 'package:actividad_api/objects.dart';
import 'dart:convert';

class ApiService {

   final String baseUrl = 'https://api.restful-api.dev/objects';

  //GET
  Future<List<Objects>> getObjects() async {
    final response = await http.get(Uri.parse(baseUrl));

    if (response.statusCode == 200) {
      List<dynamic> jsonData = jsonDecode(response.body);
      return jsonData.map((dynamic item){
        return Objects.fromMap(item);
      }).toList();
    } else {
      throw Exception('Failed to load objects');
    }
  }

  //POST
  Future<Objects> createObject(Objects obj) async {
    final response = await http.post(
      Uri.parse(baseUrl),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(obj.toMap()),
    );

    if (response.statusCode == 201) {
      print("Object successfully");
      return Objects.fromMap(json.decode(response.body));
    } else {
      throw Exception('Failed to create object');
    }
  }

  //PUT
  Future<Objects> updateObject(Objects obj) async {
    final response = await http.put(
      Uri.parse('$baseUrl/${obj.id}'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(obj.toMap()),
    );

    if (response.statusCode == 200) {
      print("Object updated successfully");
      return Objects.fromMap(json.decode(response.body));
    } else {
      throw Exception('Failed to update album');
    }
  }

  //DELETE
  Future<void> deleteObject(int id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/$id'),
    );

    if(response.statusCode == 200) {
      print('Object deleted successfully');
    } else{
      throw Exception('Failed to delete object');
    }

  }


}

