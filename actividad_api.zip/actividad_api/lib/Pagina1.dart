import 'package:flutter/material.dart';
import 'package:actividad_api/objects.dart';
import 'package:actividad_api/api_service.dart';


class Pagina1 extends StatefulWidget {
  const Pagina1({super.key});

  @override
  State<Pagina1> createState() => _Pagina1State();
  
}

class _Pagina1State extends State<Pagina1> {

  List<Objects> object = [];
  ApiService apiService = ApiService();

  @override
  void initState(){
    super.initState();
    _refreshObject();
  }

  void _refreshObject() {
    apiService.getObjects().then((value) {
      setState(() {
        object = value;
      });
    });
  }

  void createObject(){
    int id = 0;
    String name = '';
    List<dynamic>? data;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Create Object', style: TextStyle(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(labelText: 'ID'),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  id = int.tryParse(value) ?? 0;
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Name'),
                onChanged: (value) {
                  name = value;
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Data'),
                onChanged: (value) {
                  data = value.split(',').map((e) => e.trim()).toList();
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                apiService.createObject(
                  Objects(id: id, name: name, data: data),
                ).then((_) {
                  _refreshObject();
                  Navigator.of(context).pop();
                });
              },
              child: Text('Crear'),
            ),
          ],
        );
      },
    );
  }

  void updateObject(){
    int id = 0;
    String name = '';
    List<dynamic>? data;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Actualizar Objeto', style: TextStyle(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(labelText: 'ID del Objecto'),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  id = int.tryParse(value) ?? 0;
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Nombre del Objecto'),
                onChanged: (value) {
                  name = value;
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Data'),
                onChanged: (value) {
                  data = value.split(',').map((e) => e.trim()).toList();
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                apiService.updateObject(
                  Objects(id: id, name: name, data: data),
                ).then((_) {
                  _refreshObject();
                  Navigator.of(context).pop();
                });
              },
              child: Text('Actualizar'),
            ),
          ],
        );
      },
    );
  }

  void _deleteObject() {
    int id = 0;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Eliminar Objecto', style: TextStyle(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(labelText: 'ID del Objeto a Eliminar'),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  id = int.tryParse(value) ?? 0;
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                apiService.deleteObject(id).then((_) {
                  _refreshObject();
                  Navigator.of(context).pop();
                });
              },
              child: Text('Eliminar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
	return Scaffold(
	  appBar: AppBar(
		title: Text('Objetos'),
    backgroundColor: Colors.purple,
    foregroundColor: Colors.white,
	  ),
	  body: ListView.builder(
        itemCount: object.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8, horizontal: 10),
            child: ListTile(
              title: Text(object[index].name, style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('ID del Álbum: ${object[index].id} - Nombre de Objetos: ${object[index].name}'),
              contentPadding: EdgeInsets.all(10),
            ),
          );
        },
      ),
  
  floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: createObject,
            child: Icon(Icons.add),
            heroTag: 'add',
            backgroundColor: Colors.green,
          ),
          SizedBox(height: 10),
          FloatingActionButton(
            onPressed: updateObject,
            child: Icon(Icons.edit),
            heroTag: 'edit',
            backgroundColor: Colors.blue,
          ),
          SizedBox(height: 10),
          FloatingActionButton(
            onPressed: () {
              if (object.isNotEmpty) {
                _deleteObject();
              }
            },
            child: Icon(Icons.delete),
            heroTag: 'delete',
            backgroundColor: Colors.red,
          ),
        ],
      ),
	  );
  }
}