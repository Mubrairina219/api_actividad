import 'package:flutter/material.dart';
import 'package:actividad_api/objects.dart';
import 'package:actividad_api/api_service.dart';

class Pagina1 extends StatefulWidget {
  const Pagina1({super.key});

  @override
  State<Pagina1> createState() => _Pagina1State();
}

class _Pagina1State extends State<Pagina1> {
  List<Objects> object = [];
  ApiService apiService = ApiService();

  @override
  void initState() {
    super.initState();
    _refreshObject();
  }

  void _refreshObject() {
    apiService.getObjects().then((value) {
      setState(() {
        object = value;
      });
    }).catchError((error) {
      // Manejo de errores
      print("Error al obtener objetos: $error");
    });
  }

  void createObject() {
    int id = 0;
    String name = '';
    Map<String, dynamic>? data;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Crear Objeto', style: TextStyle(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(labelText: 'ID'),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  id = int.tryParse(value) ?? 0;
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Nombre'),
                onChanged: (value) {
                  name = value;
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Data (formato: clave1:valor1, clave2:valor2)'),
                onChanged: (value) {
                  data = {};
                  var pairs = value.split(',');
                  for (var pair in pairs) {
                    var keyValue = pair.split(':');
                    if (keyValue.length == 2) {
                      data![keyValue[0].trim()] = keyValue[1].trim();
                    }
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                if (id > 0 && name.isNotEmpty && data != null) {
                  apiService.createObject(
                    Objects(id: id, name: name, data: data),
                  ).then((_) {
                    _refreshObject();
                    Navigator.of(context).pop();
                  }).catchError((error) {
                    print("Error al crear objeto: $error");
                  });
                } else {
                  print("Por favor, completa todos los campos correctamente.");
                }
              },
              child: Text('Crear'),
            ),
          ],
        );
      },
    );
  }

  void updateObject() {
    int id = 0;
    String name = '';
    Map<String, dynamic>? data;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Actualizar Objeto', style: TextStyle(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(labelText: 'ID del Objeto'),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  id = int.tryParse(value) ?? 0;
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Nombre del Objeto'),
                onChanged: (value) {
                  name = value;
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Data (formato: clave1:valor1, clave2:valor2)'),
                onChanged: (value) {
                  data = {};
                  var pairs = value.split(',');
                  for (var pair in pairs) {
                    var keyValue = pair.split(':');
                    if (keyValue.length == 2) {
                      data![keyValue[0].trim()] = keyValue[1].trim();
                    }
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                if (id > 0 && name.isNotEmpty && data != null) {
                  apiService.updateObject(
                    Objects(id: id, name: name, data: data),
                  ).then((_) {
                    _refreshObject();
                    Navigator.of(context).pop();
                  }).catchError((error) {
                    print("Error al actualizar objeto: $error");
                  });
                } else {
                  print("Por favor, completa todos los campos correctamente.");
                }
              },
              child: Text('Actualizar'),
            ),
          ],
        );
      },
    );
  }

  void _deleteObject() {
    int id = 0;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Eliminar Objeto', style: TextStyle(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(labelText: 'ID del Objeto a Eliminar'),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  id = int.tryParse(value) ?? 0;
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                if (id > 0) {
                  apiService.deleteObject(id).then((_) {
                    _refreshObject();
                    Navigator.of(context).pop();
                  }).catchError((error) {
                    print("Error al eliminar objeto: $error");
                  });
                } else {
                  print("Por favor, ingresa un ID válido.");
                }
              },
              child: Text('Eliminar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Objetos'),
        backgroundColor: Colors.purple,
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
        itemCount: object.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8, horizontal: 10),
            child: ListTile(
              title: Text(object[index].name, style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('ID: ${object[index].id} - Nombre: ${object[index].name}'),
              contentPadding: EdgeInsets.all(10),
            ),
          );
        },
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: createObject,
            child: Icon(Icons.add),
            heroTag: 'add',
            backgroundColor: Colors.green,
          ),
          SizedBox(height: 10),
          FloatingActionButton(
            onPressed: updateObject,
            child: Icon(Icons.edit),
            heroTag: 'edit',
            backgroundColor: Colors.blue,
          ),
          SizedBox(height: 10),
          FloatingActionButton(
            onPressed: () {
              if (object.isNotEmpty) {
                _deleteObject();
              }
            },
            child: Icon(Icons.delete),
            heroTag: 'delete',
            backgroundColor: Colors.red,
          ),
        ],
      ),
    );
  }
}