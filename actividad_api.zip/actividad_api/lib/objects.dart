class Objects {

  int id;
  String name;
  List<dynamic>? data;

  Objects({required this.id, required this.name, this.data});

  //from Map
  factory Objects.fromMap(Map<String, dynamic> obj) {
    return Objects(
      id: obj['id'],
      name: obj['name'],
      data: obj['data'],
    );
  }

  //to Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'data': data,
    };
  }

}